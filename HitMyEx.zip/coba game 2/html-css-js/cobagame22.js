const sampah = document.querySelectorAll('.sampah');
const orang = document.querySelectorAll('.orang');
const papanSkor = document.querySelector('.papanSkor');
const pop = document.querySelector('#pop');

let sampahSebelumnya;
let selesai;
let skor;

function randomSampah(sampah){
    const t = Math.floor(Math.random() * sampah.length);
    const tRandom = sampah[t];
    if (tRandom == sampahSebelumnya){
        randomSampah(sampah);
    }
    sampahSebelumnya = tRandom;
    return tRandom;

}

function randomWaktu(min, max){
    return Math.round(Math.random() * (max - min) + min);
}


function munculkanOrang(){
    const tRandom = randomSampah(sampah);
    const wRandom = randomWaktu(400,1000);
    tRandom.classList.add('muncul');
    setTimeout(() => {
        tRandom.classList.remove('muncul');
        if(!selesai) {
            munculkanOrang(); 
        }
        else
        {
            var x = document.getElementById("HiddenStart"); 
            x.hidden = false;
        }
    }, wRandom);
}


function mulai(){
    var x = document.getElementById("HiddenStart");  
    x.hidden = true;
    selesai = false;
    skor = 0;
    papanSkor.textContent = 0;
    munculkanOrang();
    setTimeout(() => {
        selesai = true;
    }, 10000);     
}

function pukul(){
    skor++;
    this.parentNode.classList.remove('muncul');
    pop.play();
    papanSkor.textContent = skor;
}

orang.forEach(t => {
    t.addEventListener('click', pukul);
});